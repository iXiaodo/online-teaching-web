#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright @ 2014 Mitchell Chu

import io

import tornado_session

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

version = tornado_session.version

setup(
    name='tornado_session',
    version=version,
    description="Extensions for torndsession",
    classifiers=[
        'License :: OSI Approved :: MIT License',
        'Topic :: Internet :: WWW/HTTP :: Session',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'Operating System :: OS Independent',
    ],
    keywords='torndsession tornado session redis memcached memory file python',
    author="WHB",
    license="MIT",
    packages=["tornado_session"],
    include_package_data=True,
    zip_safe=True,
    install_requires=['tornado',],
)
